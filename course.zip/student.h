/**
 * @brief Here we have a structure type called _student
 *        which contains student first and last name, 
 *        and their student id, and grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50];    /**< this is the student's first_name */
  char last_name[50];     /**< this is the student's last_name */
  char id[11];            /**< this is the student's student id */
  double *grades;         /**< this is the student's grades */
  int num_grades;         /**< this is the student's total numbers of grades */
} Student;

// Here are some functions will be defined in student.c file.

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
