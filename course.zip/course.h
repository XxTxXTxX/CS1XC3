/**
 * @file course.h
 * @author Sharmin Ahmed (you@domain.com)
 * @brief Here we defined a structure type called _course, and also defined
 *        some functions below.
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100];   /**< this is the course_name */
  char code[10];    /**< this is the course_code */
  Student *students;    /**< this is the Student type's pointer */
  int total_students;   /**< this is the total student number */
} Course;

// Here is the functions we will define in course.c file.
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


