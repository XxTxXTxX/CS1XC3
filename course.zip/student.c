/**
 * @file student.c
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief This is the info about the function add_grade
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // Here we can add a grade to the student, the below function checks if
  // the student only has one grades, it will automatically allocate 1 space
  // of double in student's grades
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  // Below code says if the student has more than 1 grades, we need to
  // reallocate the size of student's grade space because there is already
  // exist one grade.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief Here is the info about function average, it counts the student's
 *        average grade.
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  // Below codes add all of a student's grades, and divided by the total
  // number of grades to get the average grade of one student.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**
 * @brief Here is the info about function print_student, call this function
 *        will print a student's information about Name, Student ID, Grades,
 *        and Average grades.
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief Here is the info about function generate_random_student
 *        
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  // Here below 2 functions initialized the students' first name and last name.
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  // Here it defineds a student type variable called new_student, which is a 
  // pointer, and it will allocate 1 space contains Student size.
  Student *new_student = calloc(1, sizeof(Student));

  // Here the initialized student's first name and last name are being randomlly put
  // into new_student.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
  
  // Here we are giving the student's student id.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // Here we are calling add_grade function to randomly assign new student's grade.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}