/**
 * @file course.c
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-08
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This is the info about the function enroll_student.
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // Here we assign a course for the student, the below function checks if
  // the course has only one student, it will automatically allocate 1 space
  // of type Student.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // Below code says if the course has more than 1 student, we need to
  // reallocate the size of students in course because there is already
  // exist one student, so the space we previously allocated is full.
  // Therefore, we need to realloc size to find enough space in the ram
  // that able to contain all the students.
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief This is the info about the function print_course.
 * 
 * @param course 
 */
void print_course(Course* course)
{
  // If we call this function, the course name, course code, total student
  // in the course will be printed out.
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief This is the info about the function top_student.
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  // Here if we don't have any student in the course, return nothing.
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  // Here we used for loop to find the highest_grade student. First
  // we go through all the students in that course, and assign the first
  // student grade as the maximum grade, then we check if the next student's
  // grade is higher than the maximum grade we set before, if it is, then we
  // set the maximum grade to the new student's grades and go through all the
  // student to find the highest grade.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief This is the info about the function passing.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  // Here the for loop is checking if the student's average grade
  // is higher than 50, the grade is not higher than 50, we don't count
  // this student to the passing count.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  // Here we allocate the same number of count spaces, which contains
  // Student size.
  passing = calloc(count, sizeof(Student));

  int j = 0;
  // In this for loop, it is trying to put all the passing students to
  // a passing list so we can see who pass the course.
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}